package com.talent_sprint.cropcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
